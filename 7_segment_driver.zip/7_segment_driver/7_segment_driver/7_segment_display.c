/*
 * _7_segmant_display.c
 *
 * Created: 06-May-18 6:19:49 PM
 *  Author: Vlado
 */ 

#include <avr/io.h>
#include <avr/sfr_defs.h>
#include <stddef.h>
#include "I7_segment_display.h"
#include <avr/interrupt.h>
#include <math.h>
#include "IUtils.h"

static uint8_t indexx = 0;
static uint8_t displayNum[4] = {0,0,0,0};

void display_7_segment(double num, uint8_t decimals){
	if(count_whole(num) + decimals > 4)
		decimals = 4-count_whole(num);
		
	if(num > 9999 || num < 0)
		return;
	if(decimals > 3 || decimals < 0)
		return;
	
	num =  (num * pow(10.0 , decimals)) + 0.5;
	uint16_t number = num;
	
	displayNum[0] = get_number(number/1000);
	displayNum[1] = get_number((number/100)%10);
	displayNum[2] = get_number((number/10)%10);
	displayNum[3] = get_number(number%10);
	
	if(decimals == 3)
	{displayNum[0]--;}
	else if(decimals == 2)
	{displayNum[1]--;}
	else if(decimals == 1)
	{displayNum[2]--;}
}

//ISR(TIMER4_COMPA_vect)
//{
	//uint8_t i = indexx%4;
	//load_digit(displayNum[i], i);
	//indexx++;
//}

void create_display()
{
	//Set display pins as output
	DDRB |= _BV(DDB0) |_BV(DDB1) |_BV(DDB2);
	DDRF |= _BV(DDF0) |_BV(DDF1) |_BV(DDF2) |_BV(DDF3);
	//Set timer 4
	sei();
	TIMSK4 |= _BV(OCIE4A);
	OCR4A = 6665;
	TCCR4B |= _BV(WGM42) |_BV(CS41);
}

void load_digit(uint8_t number, uint8_t position){
	uint8_t pattern = number;
	
	for(int i = 0; i < 8; i++){
		(pattern & 1) ? (PORTB |= (_BV(PB2))) : (PORTB &= ~(_BV(PB2)));	//set SI
		pattern = pattern >> 1;
		toggle_SCK();
	}
	toggle_RCK();
	toggle_position(position);
}

