/*
 * _7_segmant_display_SPI.c
 *
 * Created: 06-May-18 6:19:49 PM
 *  Author: Vlado
 */ 

#include <avr/io.h>
#include <avr/sfr_defs.h>
#include <stddef.h>
#include "I7_segment_display_SPI.h"
#include <avr/interrupt.h>
#include <math.h>
#include "IUtils.h"

static uint8_t indexx = 0;
static uint8_t displayNum[4] = {0,0,0,0};
static uint8_t done = 0;

void SPI_MasterInit(void)
{
	/* Set MOSI and SCK output, all others input */
	DDRB = (1<<DDB2)|(1<<DDB1)|(1<<DDB0);
	/* Enable SPI, Master, set clock rate fck/16 */
	SPCR = (1<<SPE)|(1<<MSTR)|(1<<SPR0)|(1<<5)|(1<<SPIE);
}

void create_display_SPI()
{
	//Set display pins as output
	DDRB |= _BV(DDB0) |_BV(DDB1) |_BV(DDB2);
	DDRF |= _BV(DDF0) |_BV(DDF1) |_BV(DDF2) |_BV(DDF3);
	//Set timer 4
	sei();
	TIMSK4 |= _BV(OCIE4A);
	OCR4A = 6665;
	TCCR4B |= _BV(WGM42) |_BV(CS41);
	
	SPI_MasterInit();
}

void display_7_segment_SPI(double num, uint8_t decimals){
	if(count_whole(num) + decimals > 4)
		decimals = 4-count_whole(num);
		
	if(num > 9999 || num < 0)
		return;
	if(decimals > 3 || decimals < 0)
		return;
	
	num =  (num * pow(10.0 , decimals)) + 0.5;
	uint16_t number = num;
	
	displayNum[0] = get_number(number/1000);
	displayNum[1] = get_number((number/100)%10);
	displayNum[2] = get_number((number/10)%10);
	displayNum[3] = get_number(number%10);
	
	if(decimals == 3)
	{displayNum[0]--;}
	else if(decimals == 2)
	{displayNum[1]--;}
	else if(decimals == 1)
	{displayNum[2]--;}
}

ISR(TIMER4_COMPA_vect)
{
	if(done = 1){
		load_digit_SPI(displayNum[indexx%4], indexx%4);
		done = 0;
	}
}

ISR(SPI_STC_vect){
	toggle_RCK();
	toggle_position(indexx);
	
	indexx++;
	done = 1;
}

void load_digit_SPI(uint8_t number, uint8_t position){
	/* Start transmission */
	SPDR = number;
	indexx = position;
}

