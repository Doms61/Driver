/*
 * I7_segment_display.h
 *
 * Created: 06-May-18 6:20:13 PM
 *  Author: Vlado
 */ 


#ifndef I7_SEGMENT_DISPLAY_H_
#define I7_SEGMENT_DISPLAY_H_

/*!
	Constructor function for enabling the 7 segment display
*/
void create_display();

/*!
	Turns on a single digit specified by position with specified number in range 0 .. 9
*/
void load_digit(uint8_t number, uint8_t position);

/*!
	Function for controlling all 4 digits of 7 segment display
		- number can contain decimal point
		- decimals specifies number of decimal places showed (if number of integer places + decimals > 4, decimals is decremented until the condition if satisfied)
 */
void display_7_segment(double number, uint8_t decimals);

#endif /* I7_SEGMENT_DISPLAY_H_ */