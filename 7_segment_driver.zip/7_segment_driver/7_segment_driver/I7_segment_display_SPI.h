/*
 * I7_segment_display_SPI.h
 *
 * Created: 07-May-18 1:47:50 PM
 *  Author: Vlado
 */ 


#ifndef I7_SEGMENT_DISPLAY_SPI_H_
#define I7_SEGMENT_DISPLAY_SPI_H_

/*!
	Constructor function for enabling the 7 segment display	and SPI
*/
void create_display_SPI();

/*!
	Turns on a single digit specified by position with specified number in range 0 .. 9
*/
void load_digit_SPI(uint8_t number, uint8_t position);

/*!
	Function for controlling all 4 digits of 7 segment display
		- number can contain decimal point
		- decimals specifies number of decimal places showed (if number of integer places + decimals > 4, decimals is decremented until the condition if satisfied)
 */
void display_7_segment_SPI(double number, uint8_t decimals);

#endif /* I7_SEGMENT_DISPLAY_SPI_H_ */