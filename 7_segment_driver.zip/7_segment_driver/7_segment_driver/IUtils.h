#include <stdint-gcc.h>
/*
 * IUtils.h
 *
 * Created: 09-May-18 1:24:57 PM
 *  Author: Vlado
 */ 


#ifndef IUTILS_H_
#define IUTILS_H_
/**
 *	
*/

/*! \file IUtils.h
	Utils.c provides functions common to both 7_segment_display and 7_segment_display_SPI
*/

/**
 *	Returns a pattern for each digit
*/
uint8_t get_number(uint8_t number);

/**
 *	Returns number of spaces  integer places (left of decimal point)
*/ 
uint8_t count_whole(double number);

/**
 * Turns off all the digits and turns on the specified digit
 *	- position 0...3
*/
void toggle_position(uint8_t position);

/**
 *	Toggles RCK of the shift register low and high once	
 *		- used for sending the stored value of shift register
*/
void toggle_RCK();

/**
 *	Toggles latch of the shift register
 *	- used for writing a current value of SI into shift register and shifting to next place
*/
void toggle_SCK();

#endif /* IUTILS_H_ */