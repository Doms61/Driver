/*
 * Utils.c
 *
 * Created: 09-May-18 1:28:03 PM
 *  Author: Vlado
 */ 

#include <avr/io.h>
#include <avr/sfr_defs.h>
#include <stddef.h>
#include <math.h>
#include "IUtils.h"

#define NOTHING 0b11111111
#define EVERYTHING 0b00000000
#define ZERO  0b00000011
#define ONE	  0b10011111
 #define TWO	  0b00100101
#define THREE  0b00001101 
 #define FOUR   0b10011001
 #define FIVE  0b01001001
#define SIX   0b01000001
#define SEVEN 0b00011111
#define EIGHT 0b00000001
#define NINE  0b00001001

uint8_t get_number(uint8_t number){
	switch(number){
		case 0: return ZERO;
		case 1: return ONE;
		case 2: return TWO;
		case 3: return THREE;
		case 4: return FOUR;
		case 5: return FIVE;
		case 6: return SIX;
		case 7: return SEVEN;
		case 8: return EIGHT;
		case 9: return NINE;
		case 10: return EVERYTHING;
		default : return 0;
	}
}

void toggle_position(uint8_t position){
	PORTF |= (_BV(PF0));
	PORTF |= (_BV(PF1));
	PORTF |= (_BV(PF2));
	PORTF |= (_BV(PF3));

	switch(position){
		case 0: 	PORTF &= ~(_BV(PF0));
		break;
		case 1:		PORTF &= ~(_BV(PF1));
		break;
		case 2:		PORTF &= ~(_BV(PF2));
		break;
		case 3:		PORTF &= ~(_BV(PF3));
		break;
		default: break;
	}
}

uint8_t count_whole(double number){
	uint8_t num = (uint8_t) number;
	uint8_t count = 0;
	
	while(num > 0) {
		num = num/10;
		count ++;
	}
	return count;
}

void toggle_SCK(){
	PORTB &= ~(_BV(PB1));	//toggle SCK
	PORTB |= (_BV(PB1));
}

void toggle_RCK(){
	PORTB &= ~(_BV(PB0)); //toggle RCK
	PORTB |= (_BV(PB0));
}