/*
 * 7_segment_driver.c
 *
 * Created: 23-Apr-18 2:00:56 PM
 * Author : Vlado
 */ 

#include <avr/io.h>
#include <avr/sfr_defs.h>
#include <stddef.h>
#include "I7_segment_display.h"
#include "I7_segment_display_SPI.h"

// ---- //
#define F_CPU 16000000UL
#include <util/delay.h>

int main(void)
{	
	create_display_SPI();	
	display_7_segment_SPI(1234, 0);

	//create_display();
	//display_7_segment(1.2306, 3);
	
    while (1) 
    {
	}
}

