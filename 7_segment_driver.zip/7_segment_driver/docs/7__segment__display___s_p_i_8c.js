var 7__segment__display___s_p_i_8c =
[
    [ "create_display_SPI", "7__segment__display___s_p_i_8c.html#ab5decbd4c0d2a57be9c1a579820fc570", null ],
    [ "display_7_segment_SPI", "7__segment__display___s_p_i_8c.html#aa49d91db22ed9c9d3bdbb45c1c18b935", null ],
    [ "ISR", "7__segment__display___s_p_i_8c.html#a8aa6a32130ab26be17555166513a23ba", null ],
    [ "ISR", "7__segment__display___s_p_i_8c.html#af9cad97352f5ba9bbd800446131125a6", null ],
    [ "load_digit_SPI", "7__segment__display___s_p_i_8c.html#ae8ab6c73f18c073c0ea4b73b1fab2cef", null ],
    [ "SPI_MasterInit", "7__segment__display___s_p_i_8c.html#a7fcea408052a2d719378c0a0412c6616", null ]
];