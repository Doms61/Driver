var _i7__segment__display___s_p_i_8h =
[
    [ "create_display_SPI", "_i7__segment__display___s_p_i_8h.html#ab5decbd4c0d2a57be9c1a579820fc570", null ],
    [ "display_7_segment_SPI", "_i7__segment__display___s_p_i_8h.html#ae625a2a01b78e71e39b0308dcd424a98", null ],
    [ "load_digit_SPI", "_i7__segment__display___s_p_i_8h.html#ae8ab6c73f18c073c0ea4b73b1fab2cef", null ]
];