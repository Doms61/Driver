var _i_utils_8h =
[
    [ "count_whole", "_i_utils_8h.html#ae7c5e6d48e220d1afc4f41ee164f7596", null ],
    [ "get_number", "_i_utils_8h.html#ae7b1252a13e97d3f1a6070d3068e0851", null ],
    [ "toggle_position", "_i_utils_8h.html#a96c3f3eaa39e474af455dae72f4a2fa2", null ],
    [ "toggle_RCK", "_i_utils_8h.html#ad3707a5db730704b497381ae78540d91", null ],
    [ "toggle_SCK", "_i_utils_8h.html#afbec344d4f1f84fe5998038d63479e49", null ]
];