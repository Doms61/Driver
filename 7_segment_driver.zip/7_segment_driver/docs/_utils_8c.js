var _utils_8c =
[
    [ "EIGHT", "_utils_8c.html#aaf6cfeda610d5092df7deb18fd5d63c2", null ],
    [ "EVERYTHING", "_utils_8c.html#a767d892aca5ed4b04f8bbc948f9b3364", null ],
    [ "FIVE", "_utils_8c.html#a18ced145d1fdc806b5006bd4c2857026", null ],
    [ "FOUR", "_utils_8c.html#a64a9b58c6a5bcd3724f3b56ad6d006a7", null ],
    [ "NINE", "_utils_8c.html#aef08329d0c1db97d7b269330ae9a70af", null ],
    [ "NOTHING", "_utils_8c.html#aad4a7ebff687dc5228cc3fd4d25067f2", null ],
    [ "ONE", "_utils_8c.html#a206b6f5362e56b51ca957635350b70b6", null ],
    [ "SEVEN", "_utils_8c.html#ac537e6e7dad3ecef73fc3fc4f14fe020", null ],
    [ "SIX", "_utils_8c.html#afad3d8b3d66fceadb1732af784734c75", null ],
    [ "THREE", "_utils_8c.html#a1859c475c0bde19dfc1101e35d71b939", null ],
    [ "TWO", "_utils_8c.html#a888e15353eb3d330c743dbdeb47117e2", null ],
    [ "ZERO", "_utils_8c.html#ac328e551bde3d39b6d7b8cc9e048d941", null ],
    [ "count_whole", "_utils_8c.html#ae7c5e6d48e220d1afc4f41ee164f7596", null ],
    [ "get_number", "_utils_8c.html#ae7b1252a13e97d3f1a6070d3068e0851", null ],
    [ "toggle_position", "_utils_8c.html#a96c3f3eaa39e474af455dae72f4a2fa2", null ],
    [ "toggle_RCK", "_utils_8c.html#ad3707a5db730704b497381ae78540d91", null ],
    [ "toggle_SCK", "_utils_8c.html#afbec344d4f1f84fe5998038d63479e49", null ]
];